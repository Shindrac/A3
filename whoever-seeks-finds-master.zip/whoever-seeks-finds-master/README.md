# 🔍 Quem Procura Acha! - Sistema de Busca de Estabelecimentos

Sistema web para busca, cadastro e avaliação de estabelecimentos comerciais com análise de viabilidade por região.

---

## ✨ Funcionalidades

- 🏪 **Cadastro de Estabelecimentos** - Adicione novos locais
- 🔍 **Busca e Filtros** - Encontre estabelecimentos por categoria, avaliação e status
- ⭐ **Sistema de Avaliações** - Avalie e comente sobre os locais
- 🗺️ **Mapa de Análise** - Visualize viabilidade de abertura por região
- 📊 **Dashboard** - Métricas e estatísticas

---

## 🚀 Início Rápido

### Pré-requisitos
- Java 17
- PostgreSQL
- Maven (incluído via mvnw)

Acesse: http://localhost:8080

---

## 🛠️ Tecnologias

### Backend
- **Spring Boot 3.2.5** - Framework Java
- **JPA/Hibernate** - ORM
- **PostgreSQL** - Banco de dados
- **Lombok** - Redução de boilerplate

### Frontend
- **JSF (Jakarta Faces)** - Framework web
- **PrimeFaces 13** - Componentes UI
- **CSS3** - Estilização

### Integrações
- **OpenStreetMap Nominatim** - Geocoding gratuito (conversão de endereços)
- **Leaflet** - Mapas interativos gratuitos
- ✅ **100% Gratuito** - Sem necessidade de API keys ou custos

---

## 📁 Estrutura do Projeto

```
src/
├── main/
│   ├── java/
│   │   └── com/unp/ti/
│   │       ├── controller/       # Controllers JSF
│   │       ├── domain/           # Entidades JPA
│   │       ├── repository/       # Repositórios
│   │       └── service/          # Lógica de negócio
│   └── resources/
│       ├── META-INF/resources/  # Páginas XHTML
│       │   ├── css/             # Estilos
│       │   ├── estabelecimento/ # Páginas de estabelecimento
│       │   ├── index/           # Página inicial
│       │   ├── layout/          # Template
│       │   └── mapa/            # Página de mapa
│       └── application.properties # Configurações
```

---

## ✅ Status do Projeto

| Item | Status |
|------|--------|
| Backend | ✅ Completo |
| Frontend | ✅ Completo |

---

## 🎓 Desenvolvido Para

**Universidade:** Universidade Potiguar (UnP)  
**Curso:** Sistemas de Informação  
**Projeto:** Sistema de Busca de Estabelecimentos





