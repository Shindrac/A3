package com.unp.ti;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WhoeverSeeksFindsApplicationTests {

    @Test
    void contextLoads() {
    }

}
