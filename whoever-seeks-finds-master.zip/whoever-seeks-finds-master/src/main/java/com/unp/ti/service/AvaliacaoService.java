package com.unp.ti.service;

import com.unp.ti.domain.Avaliacao;
import com.unp.ti.domain.Estabelecimento;
import com.unp.ti.repository.AvaliacaoRepository;
import com.unp.ti.repository.EstabelecimentoRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
public class AvaliacaoService {

    private final AvaliacaoRepository avaliacaoRepository;
    private final EstabelecimentoRepository estabelecimentoRepository;

    public List<Avaliacao> listarPorEstabelecimento(Estabelecimento estabelecimento) {
        return avaliacaoRepository.findByEstabelecimentoOrderByDataCriacaoDesc(estabelecimento);
    }

    @Transactional
    public Avaliacao salvar(Avaliacao avaliacao) {
        // Salva a avaliação
        Avaliacao savedAvaliacao = avaliacaoRepository.save(avaliacao);

        // Recalcula a média do estabelecimento
        Estabelecimento estabelecimento = avaliacao.getEstabelecimento();
        estabelecimento.recalcularAvaliacaoMedia();
        estabelecimentoRepository.save(estabelecimento);

        return savedAvaliacao;
    }

}

