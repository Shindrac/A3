package com.unp.ti.controller;

import com.unp.ti.domain.Avaliacao;
import com.unp.ti.domain.Estabelecimento;
import com.unp.ti.service.AvaliacaoService;
import com.unp.ti.service.EstabelecimentoService;
import jakarta.annotation.PostConstruct;
import jakarta.faces.application.FacesMessage;
import jakarta.faces.context.FacesContext;
import jakarta.faces.view.ViewScoped;
import lombok.Data;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

@Component
@ViewScoped
@Data
public class AvaliacaoEstabelecimentoController implements Serializable {

    @Autowired
    private EstabelecimentoService estabelecimentoService;

    @Autowired
    private AvaliacaoService avaliacaoService;

    private Estabelecimento estabelecimento;
    private List<Avaliacao> avaliacoes;

    private String nomeUsuario;
    private Integer notaSelecionada = 0;
    private String comentario;

    private Long estabelecimentoId;

    @PostConstruct
    public void init() {
        Map<String, String> params = FacesContext.getCurrentInstance()
                .getExternalContext()
                .getRequestParameterMap();

        String idParam = params.get("id");

        try {
            if (idParam != null && !idParam.isEmpty()) {
                estabelecimentoId = Long.parseLong(idParam);
                carregarEstabelecimento();
            } else {
                carregarDadosMock();
            }
        } catch (NumberFormatException e) {
            carregarDadosMock();
        }
    }

    private void carregarEstabelecimento() {
        estabelecimento = estabelecimentoService.buscarPorId(estabelecimentoId)
                .orElse(null);

        if (estabelecimento != null) {
            avaliacoes = avaliacaoService.listarPorEstabelecimento(estabelecimento);
        } else {
            carregarDadosMock();
        }
    }

    private void carregarDadosMock() {
        estabelecimento = new Estabelecimento();
        estabelecimento.setId(1L);
        estabelecimento.setNome("Camarões Potiguar");
        estabelecimento.setTipo("Restaurante");
        estabelecimento.setDescricao("Especializado em frutos do mar, com o famoso camarão potiguar como prato principal.");
        estabelecimento.setEndereco("R. Pedro Fonseca Filho, 8887 - Ponta Negra, Natal - RN, 59090-080");
        estabelecimento.setTelefone("(84) 3209-2425");
        estabelecimento.setWebsite("www.camaroes.com.br");
        estabelecimento.setLatitude(-5.8773);
        estabelecimento.setLongitude(-35.1736);
        estabelecimento.setAvaliacaoMedia(4.9);
        estabelecimento.setTotalAvaliacoes(359);
        estabelecimento.setAberto(true);

        avaliacoes = List.of(
                criarAvaliacaoMock("Ana Clara", 5, "A comida é simplesmente divina! O camarão internacional é imperdível."),
                criarAvaliacaoMock("Bruno Costa", 4, "Lugar muito agradável, mas costuma ter fila de espera nos fins de semana.")
        );
    }

    private Avaliacao criarAvaliacaoMock(String nome, Integer nota, String texto) {
        Avaliacao avaliacao = new Avaliacao();
        avaliacao.setNomeUsuario(nome);
        avaliacao.setNota(nota);
        avaliacao.setComentario(texto);
        avaliacao.setAvatarUrl("https://ui-avatars.com/api/?name=" + nome.replace(" ", "+") + "&background=random");
        return avaliacao;
    }

    public String getEstrelas(Integer nota) {
        if (nota == null) return "";

        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 5; i++) {
            sb.append(i < nota ? "★" : "☆");
        }
        return sb.toString();
    }

    public void selecionarNota(Integer nota) {
        this.notaSelecionada = nota;
    }

    public String getEstrelasAvaliacao() {
        return getEstrelas(notaSelecionada);
    }

    public String getStatusClass() {
        return estabelecimento != null && estabelecimento.getAberto() ?
                "status-aberto" : "status-fechado";
    }

    public String getStatusTexto() {
        return estabelecimento != null && estabelecimento.getAberto() ?
                "Aberto agora" : "Fechado";
    }

    public String getHorariosFuncionamento() {
        if (estabelecimento != null && estabelecimento.getHorarios() != null &&
                !estabelecimento.getHorarios().isEmpty()) {
            return "Seg-Sáb: 11h30 - 23h, Dom: 11h30 - 22h";
        }
        return "Seg-Dom: 09:00 - 18:00";
    }


    public List<String> getImagensSecundarias() {
        if (estabelecimento != null && estabelecimento.getImagens() != null &&
                estabelecimento.getImagens().size() > 1) {
            return estabelecimento.getImagens().stream()
                    .filter(img -> !img.getPrincipal())
                    .limit(2)
                    .map(img -> img.getUrl())
                    .toList();
        }
        return List.of(
                "https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=400&h=300&fit=crop",
                "https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=400&h=300&fit=crop"
        );
    }

    public String getImagemPrincipal() {
        if (estabelecimento != null && estabelecimento.getImagens() != null &&
                !estabelecimento.getImagens().isEmpty()) {
            return estabelecimento.getImagens().stream()
                    .filter(img -> img.getPrincipal())
                    .findFirst()
                    .map(img -> img.getUrl())
                    .orElse(estabelecimento.getImagens().get(0).getUrl());
        }
        return "https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=800&h=600&fit=crop";
    }

    public void enviarAvaliacao() {
        if (notaSelecionada == 0) {
            FacesContext.getCurrentInstance().addMessage(null,
                    new FacesMessage(FacesMessage.SEVERITY_WARN,
                            "Atenção!",
                            "Por favor, selecione uma nota de 1 a 5 estrelas"));
            return;
        }

        if (nomeUsuario == null || nomeUsuario.trim().isEmpty()) {
            FacesContext.getCurrentInstance().addMessage(null,
                    new FacesMessage(FacesMessage.SEVERITY_WARN,
                            "Atenção!",
                            "Por favor, informe seu nome"));
            return;
        }

        try {
            Avaliacao novaAvaliacao = new Avaliacao();
            novaAvaliacao.setEstabelecimento(estabelecimento);
            novaAvaliacao.setNomeUsuario(nomeUsuario);
            novaAvaliacao.setNota(notaSelecionada);
            novaAvaliacao.setComentario(comentario);
            novaAvaliacao.setAvatarUrl("https://ui-avatars.com/api/?name=" +
                    nomeUsuario.replace(" ", "+") + "&background=random");

            avaliacaoService.salvar(novaAvaliacao);

            FacesContext.getCurrentInstance().addMessage(null,
                    new FacesMessage(FacesMessage.SEVERITY_INFO,
                            "Sucesso!",
                            "Avaliação enviada com sucesso!"));

            nomeUsuario = null;
            notaSelecionada = 0;
            comentario = null;

        } catch (Exception e) {
            FacesContext.getCurrentInstance().addMessage(null,
                    new FacesMessage(FacesMessage.SEVERITY_ERROR,
                            "Erro!",
                            "Erro ao enviar avaliação: " + e.getMessage()));
        }
    }
}

