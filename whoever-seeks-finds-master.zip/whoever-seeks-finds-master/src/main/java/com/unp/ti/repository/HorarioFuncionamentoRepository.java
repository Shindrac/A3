package com.unp.ti.repository;

import com.unp.ti.domain.HorarioFuncionamento;
import com.unp.ti.domain.Estabelecimento;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface HorarioFuncionamentoRepository extends JpaRepository<HorarioFuncionamento, Long> {

    List<HorarioFuncionamento> findByEstabelecimento(Estabelecimento estabelecimento);

    void deleteByEstabelecimento(Estabelecimento estabelecimento);
}

