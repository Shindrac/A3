package com.unp.ti.service;

import com.unp.ti.domain.Estabelecimento;
import com.unp.ti.domain.ImagemEstabelecimento;
import com.unp.ti.repository.EstabelecimentoRepository;
import com.unp.ti.repository.ImagemEstabelecimentoRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class EstabelecimentoService {

    private final EstabelecimentoRepository estabelecimentoRepository;
    private final ImagemEstabelecimentoRepository imagemRepository;
    private final NominatimService nominatimService;

    public List<Estabelecimento> listarTodos() {
        return estabelecimentoRepository.findAll();
    }

    public Optional<Estabelecimento> buscarPorId(Long id) {
        return estabelecimentoRepository.findById(id);
    }

    public List<Estabelecimento> buscar(String texto) {
        return estabelecimentoRepository.buscarPorTexto(texto);
    }


    @Transactional
    public Estabelecimento salvar(Estabelecimento estabelecimento) {
        if (estabelecimento.getEndereco() != null && !estabelecimento.getEndereco().isEmpty()) {
            try {
                double[] coords = nominatimService.buscarCoordenadas(estabelecimento.getEndereco());
                if (coords != null) {
                    estabelecimento.setLatitude(coords[0]);
                    estabelecimento.setLongitude(coords[1]);
                }
            } catch (Exception e) {
                System.err.println("Erro ao buscar coordenadas: " + e.getMessage());
            }
        }

        return estabelecimentoRepository.save(estabelecimento);
    }


    @Transactional
    public void adicionarImagem(Long estabelecimentoId, String url, boolean principal) {
        Optional<Estabelecimento> estabelecimento = estabelecimentoRepository.findById(estabelecimentoId);
        estabelecimento.ifPresent(est -> {
            ImagemEstabelecimento imagem = new ImagemEstabelecimento();
            imagem.setEstabelecimento(est);
            imagem.setUrl(url);
            imagem.setPrincipal(principal);
            imagemRepository.save(imagem);
        });
    }

    public List<Estabelecimento> buscarProximos(String endereco) {
        try {
            return nominatimService.buscarEstabelecimentosProximos(endereco);
        } catch (Exception e) {
            System.err.println("Erro ao buscar estabelecimentos próximos: " + e.getMessage());
            return List.of();
        }
    }
}

