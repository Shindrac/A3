package com.unp.ti.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.unp.ti.domain.Estabelecimento;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.util.ArrayList;
import java.util.List;

/**
 * Serviço gratuito para geocodificação usando OpenStreetMap Nominatim
 * Alternativa gratuita ao Google Places API
 */
@Service
public class NominatimService {

    private final RestTemplate restTemplate = new RestTemplate();
    private static final String NOMINATIM_BASE_URL = "https://nominatim.openstreetmap.org";
    private static final String TIPO_RESTAURANTE = "restaurante";

    /**
     * Busca coordenadas (latitude e longitude) de um endereço usando Nominatim (gratuito)
     */
    public double[] buscarCoordenadas(String endereco) {
        try {
            String url = UriComponentsBuilder
                    .fromHttpUrl(NOMINATIM_BASE_URL + "/search")
                    .queryParam("format", "json")
                    .queryParam("q", endereco + ", Natal, RN, Brasil")
                    .queryParam("limit", "1")
                    .toUriString();

            JsonNode[] response = restTemplate.getForObject(url, JsonNode[].class);

            if (response != null && response.length > 0) {
                JsonNode result = response[0];
                double lat = result.get("lat").asDouble();
                double lon = result.get("lon").asDouble();
                return new double[]{lat, lon};
            }
        } catch (Exception e) {
            System.err.println("Erro ao buscar coordenadas via Nominatim: " + e.getMessage());
        }

        // Retorna coordenadas padrão de Natal/RN se não conseguir buscar
        return new double[]{-5.7944778, -35.2409234};
    }

    /**
     * Busca estabelecimentos próximos a um endereço
     * Nota: Como Nominatim não tem busca de lugares como o Google Places,
     * esta funcionalidade retorna estabelecimentos mock/cadastrados no banco
     */
    public List<Estabelecimento> buscarEstabelecimentosProximos(String endereco) {
        // Validar coordenadas do endereço
        double[] coords = buscarCoordenadas(endereco);

        if (coords == null) {
            return criarEstabelecimentosMock();
        }

        // Para implementação completa, você pode:
        // 1. Buscar estabelecimentos do seu banco de dados próximos às coordenadas
        // 2. Usar Overpass API (OpenStreetMap) para buscar POIs próximos
        // 3. Retornar estabelecimentos mock como demonstração

        return criarEstabelecimentosMock();
    }


    /**
     * Cria estabelecimentos mock para demonstração
     */
    private List<Estabelecimento> criarEstabelecimentosMock() {
        List<Estabelecimento> estabelecimentos = new ArrayList<>();

        Estabelecimento est1 = new Estabelecimento();
        est1.setNome("Camarões Potiguar");
        est1.setTipo(TIPO_RESTAURANTE);
        est1.setDescricao("Especializado em frutos do mar, com o famoso camarão potiguar como prato principal.");
        est1.setEndereco("R. Pedro Fonseca Filho, 8887 - Ponta Negra, Natal - RN");
        est1.setLatitude(-5.8773);
        est1.setLongitude(-35.1736);
        est1.setAvaliacaoMedia(4.8);
        est1.setTotalAvaliacoes(258);
        est1.setAberto(true);
        est1.setTelefone("(84) 3209-2425");
        est1.setWebsite("www.camaroes.com.br");
        estabelecimentos.add(est1);

        Estabelecimento est2 = new Estabelecimento();
        est2.setNome("Mangai");
        est2.setTipo(TIPO_RESTAURANTE);
        est2.setDescricao("Restaurante com um vasto buffet de comidas típicas nordestinas.");
        est2.setEndereco("Av. Amintas Barros, 3300 - Lagoa Nova, Natal - RN");
        est2.setLatitude(-5.8670);
        est2.setLongitude(-35.1814);
        est2.setAvaliacaoMedia(4.9);
        est2.setTotalAvaliacoes(312);
        est2.setAberto(true);
        est2.setTelefone("(84) 3206-3344");
        estabelecimentos.add(est2);

        Estabelecimento est3 = new Estabelecimento();
        est3.setNome("Tábua de Carne");
        est3.setTipo(TIPO_RESTAURANTE);
        est3.setDescricao("Churrascaria especializada em carnes nobres.");
        est3.setEndereco("Av. Eng. Roberto Freire, 2610 - Ponta Negra, Natal - RN");
        est3.setLatitude(-5.8654);
        est3.setLongitude(-35.1745);
        est3.setAvaliacaoMedia(4.7);
        est3.setTotalAvaliacoes(189);
        est3.setAberto(true);
        estabelecimentos.add(est3);

        Estabelecimento est4 = new Estabelecimento();
        est4.setNome("Camarões Restaurante");
        est4.setTipo(TIPO_RESTAURANTE);
        est4.setDescricao("Tradição em frutos do mar no Rio Grande do Norte.");
        est4.setEndereco("Av. Praia de Ponta Negra - Ponta Negra, Natal - RN");
        est4.setLatitude(-5.8810);
        est4.setLongitude(-35.1688);
        est4.setAvaliacaoMedia(4.6);
        est4.setTotalAvaliacoes(445);
        est4.setAberto(true);
        est4.setTelefone("(84) 3219-2424");
        estabelecimentos.add(est4);

        Estabelecimento est5 = new Estabelecimento();
        est5.setNome("Chaplin");
        est5.setTipo(TIPO_RESTAURANTE);
        est5.setDescricao("Pizzaria e restaurante com ambiente agradável.");
        est5.setEndereco("Av. Eng. Roberto Freire, 2975 - Capim Macio, Natal - RN");
        est5.setLatitude(-5.8566);
        est5.setLongitude(-35.1852);
        est5.setAvaliacaoMedia(4.5);
        est5.setTotalAvaliacoes(167);
        est5.setAberto(true);
        est5.setTelefone("(84) 3217-2999");
        estabelecimentos.add(est5);

        return estabelecimentos;
    }
}

