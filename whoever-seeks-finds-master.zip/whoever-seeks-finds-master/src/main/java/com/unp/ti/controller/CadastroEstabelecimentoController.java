package com.unp.ti.controller;

import com.unp.ti.domain.Estabelecimento;
import com.unp.ti.domain.HorarioFuncionamento;
import com.unp.ti.service.EstabelecimentoService;
import jakarta.annotation.PostConstruct;
import jakarta.faces.application.FacesMessage;
import jakarta.faces.context.FacesContext;
import jakarta.faces.view.ViewScoped;
import lombok.Data;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

@Component
@ViewScoped
@Data
public class CadastroEstabelecimentoController implements Serializable {

    @Autowired
    private EstabelecimentoService estabelecimentoService;

    private Estabelecimento estabelecimento;
    private List<HorarioFuncionamento> horarios;

    @PostConstruct
    public void init() {
        estabelecimento = new Estabelecimento();
        horarios = new ArrayList<>();
    }

    public void salvar() {
        try {
            Estabelecimento saved = estabelecimentoService.salvar(estabelecimento);

            if (saved.getImagens().isEmpty()) {
                estabelecimentoService.adicionarImagem(
                    saved.getId(),
                    "https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=800&h=600&fit=crop",
                    true
                );
            }

            FacesContext.getCurrentInstance().addMessage(null,
                new FacesMessage(FacesMessage.SEVERITY_INFO,
                    "Sucesso!",
                    "Estabelecimento cadastrado com sucesso!"));

            init();

        } catch (Exception e) {
            FacesContext.getCurrentInstance().addMessage(null,
                new FacesMessage(FacesMessage.SEVERITY_ERROR,
                    "Erro!",
                    "Erro ao cadastrar estabelecimento: " + e.getMessage()));
        }
    }

    public void cancelar() {
        init();
        FacesContext.getCurrentInstance().addMessage(null,
            new FacesMessage(FacesMessage.SEVERITY_INFO,
                "Cancelado",
                "Cadastro cancelado"));
    }

    public String[] getTiposEstabelecimento() {
        return new String[]{"restaurante", "bar", "cafe", "lanchonete"};
    }

    public String[] getDiasSemana() {
        return new String[]{"Segunda", "Terça", "Quarta", "Quinta", "Sexta", "Sábado", "Domingo"};
    }
}

