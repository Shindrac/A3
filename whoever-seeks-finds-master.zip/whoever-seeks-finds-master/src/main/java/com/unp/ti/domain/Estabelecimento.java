package com.unp.ti.domain;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "estabelecimento")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Estabelecimento {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String nome;

    @Column(nullable = false)
    private String tipo;

    private String cnpj;

    @Column(columnDefinition = "TEXT")
    private String descricao;

    private String endereco;

    private String telefone;

    private String email;

    private String website;

    private Double latitude;
    private Double longitude;

    private String googlePlaceId;

    private Boolean aberto = true;

    private Double avaliacaoMedia = 0.0;
    private Integer totalAvaliacoes = 0;

    @Column(name = "data_criacao")
    private LocalDateTime dataCriacao;

    @Column(name = "data_atualizacao")
    private LocalDateTime dataAtualizacao;

    @OneToMany(mappedBy = "estabelecimento", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Avaliacao> avaliacoes = new ArrayList<>();

    @OneToMany(mappedBy = "estabelecimento", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<HorarioFuncionamento> horarios = new ArrayList<>();

    @OneToMany(mappedBy = "estabelecimento", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<ImagemEstabelecimento> imagens = new ArrayList<>();

    @PrePersist
    protected void onCreate() {
        dataCriacao = LocalDateTime.now();
        dataAtualizacao = LocalDateTime.now();
    }

    @PreUpdate
    protected void onUpdate() {
        dataAtualizacao = LocalDateTime.now();
    }

    public void recalcularAvaliacaoMedia() {
        if (avaliacoes == null || avaliacoes.isEmpty()) {
            avaliacaoMedia = 0.0;
            totalAvaliacoes = 0;
            return;
        }

        double soma = avaliacoes.stream()
                .mapToDouble(Avaliacao::getNota)
                .sum();

        totalAvaliacoes = avaliacoes.size();
        avaliacaoMedia = soma / totalAvaliacoes;
    }
}

