package com.unp.ti.repository;

import com.unp.ti.domain.Avaliacao;
import com.unp.ti.domain.Estabelecimento;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface AvaliacaoRepository extends JpaRepository<Avaliacao, Long> {

    List<Avaliacao> findByEstabelecimentoOrderByDataCriacaoDesc(Estabelecimento estabelecimento);

    Long countByEstabelecimento(Estabelecimento estabelecimento);
}

