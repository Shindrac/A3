package com.unp.ti.controller;

import com.unp.ti.domain.Estabelecimento;
import com.unp.ti.service.EstabelecimentoService;
import jakarta.annotation.PostConstruct;
import jakarta.faces.view.ViewScoped;
import lombok.Data;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.Serializable;
import java.util.List;

@Component
@ViewScoped
@Data
public class MapaAnaliseController implements Serializable {

    @Autowired
    private EstabelecimentoService estabelecimentoService;

    private String bairro = "Ponta Negra";
    private String enderecoBusca;

    // Análise da região
    private Integer potencialClientes = 85; // Porcentagem
    private Integer concorrencia = 60;
    private Integer acessoVisibilidade = 75;

    private String nivelPotencial = "Alto";
    private String nivelConcorrencia = "Moderada";
    private String nivelAcesso = "Bom";

    private String resultado = "Região Promissora";
    private String descricaoResultado = "Baseado nos dados, esta região apresenta um alto potencial de clientes com concorrência moderada.";

    @PostConstruct
    public void init() {
        calcularAnalise();
    }

    public void buscarRegiao() {
        if (enderecoBusca != null && !enderecoBusca.isEmpty()) {
            bairro = enderecoBusca;
            calcularAnalise();
        }
    }

    private void calcularAnalise() {
        // Busca estabelecimentos na região
        List<Estabelecimento> estabelecimentosProximos =
            estabelecimentoService.buscarProximos(bairro + ", Natal, RN");

        // Calcula métricas baseadas nos dados reais
        int totalEstabelecimentos = estabelecimentosProximos.size();

        // Potencial de clientes (inversamente proporcional à concorrência)
        if (totalEstabelecimentos < 5) {
            potencialClientes = 90;
            nivelPotencial = "Muito Alto";
        } else if (totalEstabelecimentos < 10) {
            potencialClientes = 75;
            nivelPotencial = "Alto";
        } else if (totalEstabelecimentos < 15) {
            potencialClientes = 60;
            nivelPotencial = "Médio";
        } else {
            potencialClientes = 40;
            nivelPotencial = "Baixo";
        }

        // Concorrência (proporcional ao número de estabelecimentos)
        if (totalEstabelecimentos < 5) {
            concorrencia = 30;
            nivelConcorrencia = "Baixa";
        } else if (totalEstabelecimentos < 10) {
            concorrencia = 50;
            nivelConcorrencia = "Moderada";
        } else if (totalEstabelecimentos < 15) {
            concorrencia = 70;
            nivelConcorrencia = "Alta";
        } else {
            concorrencia = 85;
            nivelConcorrencia = "Muito Alta";
        }

        // Acesso (baseado em média de avaliações da região)
        double mediaAvaliacoes = estabelecimentosProximos.stream()
            .mapToDouble(e -> e.getAvaliacaoMedia() != null ? e.getAvaliacaoMedia() : 0.0)
            .average()
            .orElse(3.5);

        acessoVisibilidade = (int) ((mediaAvaliacoes / 5.0) * 100);

        if (acessoVisibilidade >= 80) {
            nivelAcesso = "Excelente";
        } else if (acessoVisibilidade >= 60) {
            nivelAcesso = "Bom";
        } else if (acessoVisibilidade >= 40) {
            nivelAcesso = "Regular";
        } else {
            nivelAcesso = "Ruim";
        }

        // Define resultado geral
        int scoreGeral = (potencialClientes + (100 - concorrencia) + acessoVisibilidade) / 3;

        if (scoreGeral >= 70) {
            resultado = "Região Promissora";
            descricaoResultado = "Esta região apresenta excelentes condições para abertura de um novo estabelecimento, " +
                "com bom potencial de clientes e acesso adequado.";
        } else if (scoreGeral >= 50) {
            resultado = "Região com Potencial Moderado";
            descricaoResultado = "A região possui características favoráveis, mas requer análise mais detalhada " +
                "devido à concorrência ou outros fatores.";
        } else {
            resultado = "Região Desafiadora";
            descricaoResultado = "Esta região apresenta desafios significativos como alta concorrência ou " +
                "baixo potencial de clientes. Recomenda-se cautela.";
        }
    }


    public String getBarraClass(String tipo) {
        switch (tipo) {
            case "alto":
                return "barra-preenchida barra-alta";
            case "moderada":
                return "barra-preenchida barra-moderada";
            case "bom":
                return "barra-preenchida barra-bom";
            default:
                return "barra-preenchida";
        }
    }

    public String getNivelClass(String nivel) {
        if (nivel.contains("Alto") || nivel.equals("Excelente")) {
            return "analise-nivel nivel-alto";
        } else if (nivel.contains("Moderada") || nivel.equals("Bom")) {
            return "analise-nivel nivel-moderado";
        } else {
            return "analise-nivel nivel-baixo";
        }
    }

    public String getResultadoIcon() {
        if (resultado.contains("Promissora")) {
            return "pi pi-thumbs-up";
        } else if (resultado.contains("Moderado")) {
            return "pi pi-info-circle";
        } else {
            return "pi pi-exclamation-triangle";
        }
    }
}

