package com.unp.ti.domain;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "horario_funcionamento")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class HorarioFuncionamento {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "estabelecimento_id", nullable = false)
    private Estabelecimento estabelecimento;

    @Column(nullable = false)
    private String diaSemana; // Segunda, Terça, etc.

    @Column(nullable = false)
    private String horaAbertura; // 09:00 AM

    @Column(nullable = false)
    private String horaFechamento; // 06:00 PM

    private Boolean fechado = false; // Se o estabelecimento está fechado neste dia
}

