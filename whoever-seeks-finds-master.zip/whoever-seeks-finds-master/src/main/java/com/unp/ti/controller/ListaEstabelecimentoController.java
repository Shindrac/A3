package com.unp.ti.controller;

import com.unp.ti.domain.Estabelecimento;
import com.unp.ti.service.EstabelecimentoService;
import jakarta.annotation.PostConstruct;
import jakarta.faces.view.ViewScoped;
import lombok.Data;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.Serializable;
import java.util.List;
import java.util.stream.Collectors;

@Component
@ViewScoped
@Data
public class ListaEstabelecimentoController implements Serializable {

    @Autowired
    private EstabelecimentoService estabelecimentoService;

    private List<Estabelecimento> estabelecimentos;
    private List<Estabelecimento> estabelecimentosFiltrados;

    private String termoPesquisa = "Restaurantes";
    private String categoriaFiltro;
    private Boolean apenasAbertos = false;
    private Double avaliacaoMinima;
    private String ordenacao = "distancia"; // distancia, avaliacao, nome

    private Estabelecimento estabelecimentoSelecionado;

    @PostConstruct
    public void init() {
        carregarEstabelecimentos();
    }

    public void carregarEstabelecimentos() {
        estabelecimentos = estabelecimentoService.listarTodos();

        // Se não houver estabelecimentos, carrega dados mock
        if (estabelecimentos.isEmpty()) {
            carregarDadosMock();
        }

        estabelecimentosFiltrados = estabelecimentos;
        aplicarFiltros();
    }

    public void pesquisar() {
        if (termoPesquisa != null && !termoPesquisa.isEmpty()) {
            estabelecimentos = estabelecimentoService.buscar(termoPesquisa);
        } else {
            estabelecimentos = estabelecimentoService.listarTodos();
        }
        aplicarFiltros();
    }

    public void aplicarFiltros() {
        estabelecimentosFiltrados = estabelecimentos;

        // Filtro de categoria
        if (categoriaFiltro != null && !categoriaFiltro.isEmpty() && !categoriaFiltro.equals("todos")) {
            estabelecimentosFiltrados = estabelecimentosFiltrados.stream()
                .filter(e -> e.getTipo().equalsIgnoreCase(categoriaFiltro))
                .collect(Collectors.toList());
        }

        // Filtro de abertos
        if (apenasAbertos) {
            estabelecimentosFiltrados = estabelecimentosFiltrados.stream()
                .filter(Estabelecimento::getAberto)
                .collect(Collectors.toList());
        }

        // Filtro de avaliação mínima
        if (avaliacaoMinima != null && avaliacaoMinima > 0) {
            estabelecimentosFiltrados = estabelecimentosFiltrados.stream()
                .filter(e -> e.getAvaliacaoMedia() >= avaliacaoMinima)
                .collect(Collectors.toList());
        }

        // Ordenação
        ordenarLista();
    }

    private void ordenarLista() {
        if ("avaliacao".equals(ordenacao)) {
            estabelecimentosFiltrados.sort((e1, e2) ->
                Double.compare(e2.getAvaliacaoMedia(), e1.getAvaliacaoMedia()));
        } else if ("nome".equals(ordenacao)) {
            estabelecimentosFiltrados.sort((e1, e2) ->
                e1.getNome().compareTo(e2.getNome()));
        }
        // distancia mantém a ordem atual
    }

    public void toggleApenasAbertos() {
        apenasAbertos = !apenasAbertos;
        aplicarFiltros();
    }

    public void limparFiltros() {
        categoriaFiltro = null;
        apenasAbertos = false;
        avaliacaoMinima = null;
        ordenacao = "distancia";
        aplicarFiltros();
    }

    public String verDetalhes(Estabelecimento estabelecimento) {
        return "avaliacao-estabelecimento.xhtml?faces-redirect=true&id=" + estabelecimento.getId();
    }

    public String getEstrelas(Double avaliacao) {
        if (avaliacao == null) return "";

        int estrelas = (int) Math.round(avaliacao);
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 5; i++) {
            sb.append(i < estrelas ? "★" : "☆");
        }
        return sb.toString();
    }

    public String getDistancia(Estabelecimento estabelecimento) {
        // Simula distância - em produção, calcular com base na localização do usuário
        if (estabelecimento.getLatitude() != null) {
            double distancia = Math.random() * 10; // Simula 0-10km
            return String.format("%.1f km", distancia);
        }
        return "N/A";
    }

    public String getStatusBadgeClass(Boolean aberto) {
        return aberto ? "status-badge aberto" : "status-badge fechado";
    }

    public String getStatusTexto(Boolean aberto) {
        return aberto ? "Aberto" : "Fechado";
    }

    public int getTotalResultados() {
        return estabelecimentosFiltrados != null ? estabelecimentosFiltrados.size() : 0;
    }

    private void carregarDadosMock() {
        // Carrega dados de exemplo da API de Places ou dados mock
        estabelecimentos = estabelecimentoService.buscarProximos("Natal, RN");

        // Salva no banco
        for (Estabelecimento est : estabelecimentos) {
            try {
                estabelecimentoService.salvar(est);
            } catch (Exception e) {
                // Ignora erros ao salvar mock
            }
        }
    }

    public String getImagemPrincipal(Estabelecimento estabelecimento) {
        if (estabelecimento.getImagens() != null && !estabelecimento.getImagens().isEmpty()) {
            return estabelecimento.getImagens().stream()
                .filter(img -> img.getPrincipal())
                .findFirst()
                .map(img -> img.getUrl())
                .orElse(estabelecimento.getImagens().get(0).getUrl());
        }
        return "https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=800&h=600&fit=crop";
    }
}

