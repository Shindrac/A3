package com.unp.ti;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WhoeverSeeksFindsApplication {

    public static void main(String[] args) {
        SpringApplication.run(WhoeverSeeksFindsApplication.class, args);
    }

}
