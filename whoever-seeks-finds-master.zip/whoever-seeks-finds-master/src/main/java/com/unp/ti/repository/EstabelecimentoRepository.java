package com.unp.ti.repository;

import com.unp.ti.domain.Estabelecimento;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface EstabelecimentoRepository extends JpaRepository<Estabelecimento, Long> {

    List<Estabelecimento> findByTipoIgnoreCase(String tipo);

    List<Estabelecimento> findByNomeContainingIgnoreCase(String nome);

    @Query("SELECT e FROM Estabelecimento e WHERE " +
           "LOWER(e.nome) LIKE LOWER(CONCAT('%', :search, '%')) OR " +
           "LOWER(e.tipo) LIKE LOWER(CONCAT('%', :search, '%')) OR " +
           "LOWER(e.descricao) LIKE LOWER(CONCAT('%', :search, '%'))")
    List<Estabelecimento> buscarPorTexto(@Param("search") String search);

    List<Estabelecimento> findByAbertoTrue();

    List<Estabelecimento> findByAvaliacaoMediaGreaterThanEqual(Double avaliacao);

    @Query("SELECT e FROM Estabelecimento e ORDER BY e.avaliacaoMedia DESC")
    List<Estabelecimento> findAllOrderByAvaliacaoDesc();
}

