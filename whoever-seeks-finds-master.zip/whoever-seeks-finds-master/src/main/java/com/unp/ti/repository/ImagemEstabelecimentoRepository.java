package com.unp.ti.repository;

import com.unp.ti.domain.ImagemEstabelecimento;
import com.unp.ti.domain.Estabelecimento;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface ImagemEstabelecimentoRepository extends JpaRepository<ImagemEstabelecimento, Long> {

    List<ImagemEstabelecimento> findByEstabelecimento(Estabelecimento estabelecimento);

    Optional<ImagemEstabelecimento> findByEstabelecimentoAndPrincipalTrue(Estabelecimento estabelecimento);

    void deleteByEstabelecimento(Estabelecimento estabelecimento);
}

